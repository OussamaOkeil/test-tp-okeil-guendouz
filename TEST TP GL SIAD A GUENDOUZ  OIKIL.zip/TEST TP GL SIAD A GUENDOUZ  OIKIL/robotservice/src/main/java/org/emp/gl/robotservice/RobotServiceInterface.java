
package org.emp.gl.robotservice;


public interface RobotServiceInterface {
    
    public void tourneReight();
    public void tourneLeft();
    
}
