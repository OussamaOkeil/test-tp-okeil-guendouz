
package org.emp.gl.time.display;

import java.awt.Color;
import java.awt.Graphics;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.ArrayList;
import javax.swing.JFrame;





public class Labyrinthe extends JFrame implements PropertyChangeListener {
    /** Taille du pion se déplaçant dans le labyrinthe. */
    static final int tp = 18;

   /** Taille des cases du labyrinthe. */
    static final int tc = 20;

   /** Taille du décalage à gauche du labyrinthe. */
    static final int dg = 25;

   /** Taille du décalage en haut du labyrinthe. */
    static final int dh = 50;


    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if(evt.getPropertyName().equals("changementdansGUI")){
            y =((ArrayList<Integer>) evt.getOldValue()).get(0);
            x= ((ArrayList<Integer>) evt.getOldValue()).get(1);
            this.repaint();
            
        }
    }
    private int[][] labyrinthe = {
         {1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
         {1, 1, 0, 0, 1, 0, 0, 0, 0, 0 },
         {0, 0, 0, 1, 1, 1, 1, 1, 1, 0 },
         {0, 1, 0, 1, 0, 0, 0, 0, 1, 0 },
         {0, 0, 0, 0, 1, 0, 1, 1, 1, 0 },
         {0, 1, 1, 0, 1, 0, 1, 0, 0, 0},
         {1, 0, 0, 0, 0, 0, 1, 0, 1, 0},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
         {0, 0, 1, 0, 0, 0, 1, 0, 0, 0},
         };
    
    /** Position courante en x dans le labyrinthe. */
   private int x;

   /** Position courante en y dans le labyrinthe. */
   private int y;

   /** Position de départ en x dans le labyrinthe. */
   private final int xd = 0;

   /** Position de départ en y dans le labyrinthe. */
   private final int yd = 2;
   
   
   
    public Labyrinthe()
   {
      super("NOTRE labyrinthe game");
      // Initialisation du labyrinthe.
      this.x = 2;
      this.y = 2;
      setLocation(0, 0);
      setSize(295, 315);
      setVisible(true);
      setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
   }
    
    
     public void paint(Graphics g)
   {
      // Parcourt le labyrinthe.
      for(int i = 0; i < this.labyrinthe.length; i++)
      {
         for(int j = 0; j < this.labyrinthe.length; j++)
         {
            // Case libre.
            if(this.labyrinthe[i][j]==1)
            {
               g.setColor(Color.WHITE);
               g.fillRect(dg + j * tc, dh + i * tc, 
                     tc+5, tc+5);
               g.setColor(Color.black);
               g.drawRect(dg + j * tc, dh + i * tc, 
                     tc+5, tc+5);
            }
            // Mur.
            else
            {
               g.setColor(Color.GREEN);
               
               g.fillRect(dg + j * tc, dh + i * tc, 
                     tc, tc);
            }
         }
      }
      g.setColor(Color.yellow);
      g.drawRect(dg+1+this.x*tc,dh+1+this.y*tc,tp,tp);
      g.fillRect(dg+1+this.x*tc,dh+1+this.y*tc,tp,tp);
   }
}
    
    
    
    
    
