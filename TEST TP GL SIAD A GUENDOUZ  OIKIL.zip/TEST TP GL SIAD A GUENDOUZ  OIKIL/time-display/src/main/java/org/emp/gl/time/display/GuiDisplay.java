package org.emp.gl.time.display;

import java.beans.PropertyChangeEvent;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;




public class GuiDisplay extends javax.swing.JFrame implements TimerChangeListener{

    private int heure,minute,second;
    public GuiDisplay() {
        initComponents();
        Lookup.getInstance().getService(TimerService.class).addTimeChangeListener(this);
        TimerService ts = Lookup.getInstance().getService(TimerService.class);
        hourfield.setText(Integer.toString(ts.getHeures()));
        minutefield.setText(Integer.toString(ts.getMinutes()));
        secondfield.setText(Integer.toString(ts.getSecondes()));
       
    }
    
    

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        hourfield = new javax.swing.JTextField();
        minutefield = new javax.swing.JTextField();
        secondfield = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Smart Watch");
        setAlwaysOnTop(true);
        setBackground(java.awt.SystemColor.desktop);
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setForeground(new java.awt.Color(204, 255, 204));

        hourfield.setEditable(false);
        hourfield.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        hourfield.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        hourfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hourfieldActionPerformed(evt);
            }
        });

        minutefield.setEditable(false);
        minutefield.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        minutefield.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        minutefield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minutefieldActionPerformed(evt);
            }
        });

        secondfield.setEditable(false);
        secondfield.setFont(new java.awt.Font("Tahoma", 0, 25)); // NOI18N
        secondfield.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        secondfield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondfieldActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Algerian", 0, 25)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Minute");

        jLabel2.setFont(new java.awt.Font("Algerian", 0, 25)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Heure");

        jLabel3.setFont(new java.awt.Font("Algerian", 0, 25)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Seconde");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(hourfield)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 112, Short.MAX_VALUE))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(minutefield, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(secondfield, javax.swing.GroupLayout.DEFAULT_SIZE, 111, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(130, 130, 130))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(hourfield, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(minutefield, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(secondfield, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(175, 175, 175))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void secondfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_secondfieldActionPerformed

    private void minutefieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minutefieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_minutefieldActionPerformed

    private void hourfieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hourfieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_hourfieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiDisplay.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GuiDisplay().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField hourfield;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JTextField minutefield;
    private javax.swing.JTextField secondfield;
    // End of variables declaration//GEN-END:variables

    @Override
    public void propertyChange(PropertyChangeEvent pce) {
        switch(pce.getPropertyName())
        {
            
            case TimerChangeListener.SECONDE_PROP :
               // second=(int)pce.getNewValue();
                second=(Integer.parseInt(this.secondfield.getText())+1)%60;
                this.secondfield.setText(Integer.toString(second));
                break;
            case TimerChangeListener.MINUTE_PROP :
                //minute=(int)pce.getNewValue();
                 minute=(Integer.parseInt(this.minutefield.getText())+1)%60;
                this.minutefield.setText(Integer.toString(minute));
                break;
            case TimerChangeListener.HEURE_PROP :
                //heure=(int)pce.getNewValue();4
                 heure=(Integer.parseInt(this.hourfield.getText())+1)%24;
                this.hourfield.setText(Integer.toString(heure));
                
        }
        
    }
}
