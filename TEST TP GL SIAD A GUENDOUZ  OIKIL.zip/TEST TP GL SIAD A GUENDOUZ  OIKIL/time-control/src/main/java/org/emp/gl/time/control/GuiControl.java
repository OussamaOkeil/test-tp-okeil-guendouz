
package org.emp.gl.time.control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.robotservice.RobotServiceInterface;
import org.emp.gl.time.action.TimeActionInterface;
import org.emp.gl.timer.service.TimerService;


public class GuiControl extends javax.swing.JFrame implements ActionListener  {

   
    public GuiControl() {
        initComponents();
        this.Leftbutton.addActionListener(this);
        this.rightbutton.addActionListener(this);
        
    }

       @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Leftbutton = new javax.swing.JButton();
        rightbutton = new javax.swing.JButton();
        downtbutton2 = new javax.swing.JButton();
        uptbutton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Setting Smart Watch");

        Leftbutton.setBackground(new java.awt.Color(0, 0, 255));
        Leftbutton.setFont(new java.awt.Font("_PDMS_IslamicFont", 0, 14)); // NOI18N
        Leftbutton.setForeground(new java.awt.Color(51, 255, 0));
        Leftbutton.setText("Left");
        Leftbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LeftbuttonActionPerformed(evt);
            }
        });

        rightbutton.setBackground(new java.awt.Color(0, 0, 255));
        rightbutton.setFont(new java.awt.Font("_PDMS_IslamicFont", 0, 14)); // NOI18N
        rightbutton.setForeground(new java.awt.Color(51, 255, 0));
        rightbutton.setText("right");
        rightbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rightbuttonActionPerformed(evt);
            }
        });

        downtbutton2.setBackground(new java.awt.Color(0, 0, 255));
        downtbutton2.setFont(new java.awt.Font("_PDMS_IslamicFont", 0, 14)); // NOI18N
        downtbutton2.setForeground(new java.awt.Color(51, 255, 0));
        downtbutton2.setText("Down");
        downtbutton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                downtbutton2ActionPerformed(evt);
            }
        });

        uptbutton1.setBackground(new java.awt.Color(0, 0, 255));
        uptbutton1.setFont(new java.awt.Font("_PDMS_IslamicFont", 0, 14)); // NOI18N
        uptbutton1.setForeground(new java.awt.Color(51, 255, 0));
        uptbutton1.setText("Up");
        uptbutton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                uptbutton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(Leftbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(downtbutton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(10, 10, 10)
                .addComponent(rightbutton)
                .addGap(34, 34, 34))
            .addGroup(layout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addComponent(uptbutton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(uptbutton1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Leftbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(downtbutton2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rightbutton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rightbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rightbuttonActionPerformed
       // TODO add your handling code here:
    }//GEN-LAST:event_rightbuttonActionPerformed

    private void downtbutton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_downtbutton2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_downtbutton2ActionPerformed

    private void LeftbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LeftbuttonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_LeftbuttonActionPerformed

    private void uptbutton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_uptbutton1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_uptbutton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GuiControl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GuiControl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GuiControl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GuiControl.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GuiControl().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Leftbutton;
    private javax.swing.JButton downtbutton2;
    private javax.swing.JButton rightbutton;
    private javax.swing.JButton uptbutton1;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==this.Leftbutton)
        {
            
            Lookup.getInstance().getService(RobotServiceInterface.class).tourneLeft();
            
        }
         
        
        if(e.getSource()==this.rightbutton)
        {
            Lookup.getInstance().getService(RobotServiceInterface.class).tourneReight();
        }
        
    }
}
