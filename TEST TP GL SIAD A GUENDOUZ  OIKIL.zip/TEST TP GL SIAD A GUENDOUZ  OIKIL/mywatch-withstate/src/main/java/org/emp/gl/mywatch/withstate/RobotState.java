
package org.emp.gl.mywatch.withstate;

import org.emp.gl.time.action.TimeActionInterface;
import java.lang.NullPointerException;

abstract public class RobotState {
    protected  Robot robot ;
    private RobotState(){}
    public RobotState(Robot w)
    {
        if (w==null) {
        throw new NullPointerException();
          
        }
        robot=w;
    }
    
    
    public abstract void goLeft() ;
        
    

    
    public abstract void goReight() ;

    
    
}
