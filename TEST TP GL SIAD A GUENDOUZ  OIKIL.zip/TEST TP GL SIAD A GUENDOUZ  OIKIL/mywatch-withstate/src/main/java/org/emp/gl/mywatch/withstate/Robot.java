
package org.emp.gl.mywatch.withstate;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.lang.invoke.MethodHandles;
import java.util.ArrayList;
import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.robotservice.RobotServiceInterface;
import org.emp.gl.timer.service.TimerChangeListener;


public class Robot implements PropertyChangeListener,RobotServiceInterface{
    int posx=0;
    int posy=0;
    String orientation="reight";
    private PropertyChangeSupport PCS=null ;
   
   private int[][] labyrinthe = {
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 1 },
         {1, 1, 0, 0, 1, 0, 0, 0, 0, 0 },
         {0, 0, 0, 1, 1, 1, 1, 1, 1, 0 },
         {0, 1, 0, 1, 0, 0, 0, 0, 1, 0 },
         {0, 0, 0, 0, 1, 0, 1, 1, 1, 0 },
         {0, 1, 1, 0, 1, 0, 1, 0, 0, 0},
         {1, 0, 0, 0, 0, 0, 1, 0, 1, 0},
         {0, 1, 1, 1, 1, 1, 1, 1, 1, 0},
         {0, 0, 1, 0, 0, 0, 1, 0, 0, 0},
         };
    

    public Robot() {
        
        Lookup.getInstance().register(RobotServiceInterface.class,this);
        this.ws = new ReightSettingState(this);
        this.PCS =new PropertyChangeSupport(this);
    }
     private RobotState ws ;
    public void setState(RobotState nws)
    {
    ws=nws;
    }
    public void tourneLeft()
    {
        ws.goLeft();
    }
    
    public void tourneReight()
    {
        ws.goReight();
    }

        @Override
    public void propertyChange(PropertyChangeEvent evt) {
        
        if(evt.getPropertyName().equals("seconde")){
            if(orientation=="up"&&   posx>0    &&this.labyrinthe[posx-1][posy]==1)
                posx--;
            if(orientation=="down"&&  posx<9&&   this.labyrinthe[posx+1][posy]==1)
                posx++;
            if(orientation=="reight"   &&   posy<9   &&     this.labyrinthe[posx][posy+1]==1)
                posy++;
            if(orientation=="left"   &&   posy>0   &&   this.labyrinthe[posx][posy-1]==1)
                posy--; 
                ArrayList<Integer> valuers =   new ArrayList<>();
                valuers.add(posx);
                valuers.add(posy);
               PCS.firePropertyChange("changement",valuers,null);
               System.out.println(posx+" "+posy +"----->"+this.labyrinthe[posy][posx]);
        }
    }
    
    public void addTimeChangeListener(PropertyChangeListener pl) {
        
        PCS.addPropertyChangeListener(pl);
    }

    
    public void removeTimeChangeListener(PropertyChangeListener pl) {
        PCS.removePropertyChangeListener(pl);
    }
}
