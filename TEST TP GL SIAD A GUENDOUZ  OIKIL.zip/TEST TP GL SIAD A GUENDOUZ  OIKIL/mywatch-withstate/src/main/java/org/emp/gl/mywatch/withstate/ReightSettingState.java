
package org.emp.gl.mywatch.withstate;


public class ReightSettingState extends RobotState{
    public ReightSettingState(Robot w) {
   
        super(w);
    
    }

    @Override
    public void goLeft() {
         
         robot.setState(new UpState(robot));
         
         robot.orientation="up";
    }

    @Override
    public void goReight() {
       
        robot.setState(new DownSettingState(robot));
        
        robot.orientation="down";
    }
   
    
}
