
package org.emp.gl.mywatch.withstate;


public class UpState extends RobotState{

    public UpState(Robot w) {
        super(w);
    }
   
    
    @Override
    public void goLeft() {
         robot.setState(new LeftSettingState(robot));
         robot.orientation="left";
    }

    @Override
    public void goReight() {
        robot.setState(new ReightSettingState(robot));
        robot.orientation="reight";
    }
   
    
}
