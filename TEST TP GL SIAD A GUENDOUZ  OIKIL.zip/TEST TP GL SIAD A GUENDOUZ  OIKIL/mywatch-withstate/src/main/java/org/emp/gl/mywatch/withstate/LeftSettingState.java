
package org.emp.gl.mywatch.withstate;


public class LeftSettingState extends RobotState{
    public LeftSettingState(Robot w) {
       
        super(w);
    
    }

    @Override
    public void goLeft() {
        
        robot.setState(new DownSettingState(robot));
        
        robot.orientation="down";
    }

    @Override
    public void goReight() {
        robot.setState(new UpState(robot));
        robot.orientation="up";
    }

}
