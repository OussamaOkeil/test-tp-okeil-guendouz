
package org.emp.gl.time.action;


public interface TimeActionInterface {
    void goReight();
    void goLeft();
    
}
