package org.emp.gl.core.launcher;

import org.emp.gl.core.lookup.Lookup;
import org.emp.gl.gamespace.gameSpace;
import org.emp.gl.mywatch.withstate.Robot;

import org.emp.gl.time.control.GuiControl;
import org.emp.gl.time.display.GuiDisplay;
import org.emp.gl.time.display.Labyrinthe;
import folder.DummyTimeServiceImpl;
import org.emp.gl.timer.service.TimerChangeListener;
import org.emp.gl.timer.service.TimerService;
import org.emp.gl.timer.service.impl.withdelegation.TimerServiceImplWithDelegation;

/**
 * Hello world!
 *
 */
public class App {

    // ce code nous permettra d'enregistrer les service que notre application utilsiera 
    // lors de l'execution
   
    

    public static void main(String[] args) {
        
         
         TimerServiceImplWithDelegation t=new TimerServiceImplWithDelegation();
         
         
         gameSpace g=new gameSpace();
         
         Robot r=new Robot();
         
         t.addTimeChangeListener(r);

         r.addTimeChangeListener(g);
         
         java.awt.EventQueue.invokeLater(new Runnable() {
         
             public void run() {
             
                 Labyrinthe h= new Labyrinthe();
                 
                 g.addListener(h);
               
                 new GuiControl().setVisible(true);       
             }
         });
         
}
}
